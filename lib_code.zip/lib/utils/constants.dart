

import 'package:flutter/material.dart';

Color KmainColor = Colors.white;
Color KButtonColor = const Color.fromARGB(255, 216, 231, 229);
Color KtextColor = Colors.black;
Color kFieldBoarderColor = Colors.grey;